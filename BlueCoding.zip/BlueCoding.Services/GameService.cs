﻿using BlueCoding.common.Models;
using BlueConding.DbAccess;
using System.Collections.Generic;

namespace BlueCoding.Services
{
    public class GameService
    {
        private DbContext context = new DbContext();
        public IEnumerable<Games> GetGames()
        {
            return context.GetGames();
        }

        public void Save(Games game)
        {
            context.SaveGame(game);
        }
    }
}
