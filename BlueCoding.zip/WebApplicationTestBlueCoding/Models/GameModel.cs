﻿using System;


namespace WebApplicationTestBlueCoding.Models
{
    public class GameModel
    {
        public int Id { get; set; }
        public string GameName { get; set; }
        public float Price { get; set; }
        public DateTime ReleaseDate { get; set; }
    }
}