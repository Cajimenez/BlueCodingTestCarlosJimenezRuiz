﻿using BlueCoding.common.Models;
using System.Collections.Generic;
using WebApplicationTestBlueCoding.Models;

namespace WebApplicationTestBlueCoding.ViewModels
{
    public class GameModelList
    {
        public List<Games> Games { get; set; }
    }
}