﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BlueCoding.Services;
using System.Web.Mvc;
using BlueCoding.common.Models;

namespace WebApplicationTestBlueCoding.Controllers
{
    public class GameController : Controller
    {
        private GameService service = new GameService();

        // GET: Game
        public ActionResult Index()
        {
            var games = service.GetGames();

            return View(games);
        }


        [HttpGet]
        [Route("GetGames")]
        public ActionResult GetGames()
        {
            var games = service.GetGames();

            return View(games);
        }

        [HttpPost]
        [Route("SaveGames")]
        public ActionResult SaveGames(string gameName, float price, DateTime releaseDate)
        {
            try
            {
                Games game = new Games() { GameName = gameName, Price = price, ReleaseDate = releaseDate };

                service.Save(game);

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
