﻿using System;

namespace BlueCoding.common.Models
{
    public class Games
    {
        public int Id { get; set; }
        public string GameName { get; set; }
        public float Price { get; set; }
        public DateTime ReleaseDate {get; set;}
    }
}
