﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using BlueCoding.common.Models;

namespace BlueConding.DbAccess
{
    public class DbContext
    {
        readonly string connectionString;
        public DbContext()
        {
            connectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        }

        #region public methods
        public IEnumerable<Games> GetGames()
        {
            try
            {
                DataSet dataSetGames = new DataSet();

                using (SqlConnection coon = new SqlConnection(connectionString))
                {
                    coon.Open();

                    using (SqlCommand cmd = new SqlCommand("SP_GetGames",coon))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
                        sqlDataAdapter.SelectCommand = cmd;
                        sqlDataAdapter.Fill(dataSetGames);

                        return GetGamesFromDataSet(dataSetGames);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void SaveGame(Games game)
        {
            try
            {
                using (SqlConnection coon = new SqlConnection(connectionString))
                {
                    coon.Open();

                    using (SqlCommand cmd = new SqlCommand("SP_SaveGame",coon))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("GameName", game.GameName);
                        cmd.Parameters.AddWithValue("Price", game.Price);
                        cmd.Parameters.AddWithValue("ReleaseDate", game.ReleaseDate);

                        cmd.ExecuteNonQuery();
                    }
                }
            }catch(Exception ex)
            {
                throw ex;
            }
        }

        #endregion

        #region Private methods
        private IEnumerable<Games> GetGamesFromDataSet(DataSet dataSet)
        {
            if (dataSet == null || dataSet.Tables.Count == 0)
                yield break;

            var table = dataSet.Tables[0];

            foreach(DataRow row in table.Rows)
            {
                float price;
                float.TryParse(row["Price"].ToString(), out price);

                yield return new Games()
                {
                    Id = Convert.ToInt32(row["Id"].ToString()),
                    GameName = row["GameName"].ToString(),
                    Price = price,
                    ReleaseDate = DateTime.Parse(row["ReleaseDate"].ToString())
                };
            }
        }

        #endregion
    }
}
